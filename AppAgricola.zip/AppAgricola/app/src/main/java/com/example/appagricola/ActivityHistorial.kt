package com.example.appagricola

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class ActivityHistorial : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        val linearLayoutHistorial = findViewById<LinearLayout>(R.id.linearLayoutHistorial)
        val buttonSalir = findViewById<Button>(R.id.buttonSalir)

        mostrarHistorial(linearLayoutHistorial)

        // Botón para salir al menú principal
        buttonSalir.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun mostrarHistorial(linearLayout: LinearLayout) {
        linearLayout.removeAllViews()

        for (sensor in DataStorage.sensores) {
            val cardView = CardView(this)
            cardView.radius = 8f
            cardView.setContentPadding(16, 16, 16, 16)
            cardView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }

            val textView = TextView(this)
            textView.text = "Sensor: ${sensor.nombre}\nTipo: ${sensor.tipo.nombre}\n" +
                    "Ubicación: ${sensor.ubicacion.nombre}\nDescripción: ${sensor.descripcion}\nIdeal: ${sensor.ideal}"
            textView.textSize = 16f
            textView.setPadding(8, 8, 8, 8)

            cardView.addView(textView)
            linearLayout.addView(cardView)
        }
    }
}
