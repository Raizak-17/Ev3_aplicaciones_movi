package com.example.appagricola.models

data class Sensor(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val ideal: Float,
    val tipo: Tipo,
    val ubicacion: Ubicacion
)
