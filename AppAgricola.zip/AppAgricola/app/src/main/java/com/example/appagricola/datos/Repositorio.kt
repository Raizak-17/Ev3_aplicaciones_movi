package com.example.appagricola.datos

import com.example.appagricola.models.Sensor
import com.example.appagricola.models.Ubicacion
import com.example.appagricola.models.Tipo

class DataStorage private constructor() {

    // Listas públicas para almacenar datos
    val sensores: MutableList<Sensor> = mutableListOf()
    val ubicaciones: MutableList<Ubicacion> = mutableListOf()
    val tipos: MutableList<Tipo> = mutableListOf()

    init {
        // Inicializar algunos datos de ejemplo
        ubicaciones.add(Ubicacion(1, "Invernadero"))
        ubicaciones.add(Ubicacion(2, "Campo abierto"))
        ubicaciones.add(Ubicacion(3, "Almacén"))

        tipos.add(Tipo(1, "Temperatura"))
        tipos.add(Tipo(2, "Humedad"))
    }

    // Singleton para obtener la instancia de DataStorage
    companion object {
        @Volatile
        private var instance: DataStorage? = null

        fun getInstance(): DataStorage {
            return instance ?: synchronized(this) {
                instance ?: DataStorage().also { instance = it }
            }
        }
    }
}
