package com.example.appagricola

import java.util.Date

// Clase contenedora de modelos de datos
class DataModels {
    // Almacenamiento temporal de ubicaciones
    companion object {
        val ubicaciones = mutableListOf<Ubicacion>()
    }

    // Clase Ubicacion
    data class Ubicacion(
        val id: Int,
        val nombre: String,
        val descripcion: String
    )

    // Clase Tipo
    data class Tipo(
        val id: Int,
        val nombre: String
    )

    // Clase Sensor
    data class Sensor(
        val id: Int,
        val nombre: String,
        val descripcion: String,
        val ideal: Float,
        val tipo: Tipo,
        val ubicacion: Ubicacion
    )

    // Clase Registro
    data class Registro(
        val id: Int,
        val instante: Date,
        val lectura: Float,
        val sensor: Sensor
    )
}
