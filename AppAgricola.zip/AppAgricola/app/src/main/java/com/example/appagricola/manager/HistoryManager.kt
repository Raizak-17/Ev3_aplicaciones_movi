// HistoryManager.kt
package com.example.appagricola.manager

import android.content.Context
import android.content.Intent
import com.example.appagricola.ActivityHistorial

class HistoryManager(private val context: Context) {
    fun openHistoryActivity() {
        val intent = Intent(context, ActivityHistorial::class.java)
        context.startActivity(intent)
    }
}
