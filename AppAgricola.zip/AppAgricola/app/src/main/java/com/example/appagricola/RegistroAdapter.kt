package com.example.appagricola

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class RegistroAdapter(private val registros: List<DataModels.Registro>) :
    RecyclerView.Adapter<RegistroAdapter.RegistroViewHolder>() {

    class RegistroViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textViewSensorNombre: TextView = view.findViewById(R.id.textViewSensorNombre)
        val textViewLectura: TextView = view.findViewById(R.id.textViewLectura)
        val textViewFecha: TextView = view.findViewById(R.id.textViewFecha)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RegistroViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_registro, parent, false)
        return RegistroViewHolder(view)
    }

    override fun onBindViewHolder(holder: RegistroViewHolder, position: Int) {
        val registro = registros[position]
        holder.textViewSensorNombre.text = "Sensor: ${registro.sensor.nombre}"
        holder.textViewLectura.text = "Lectura: ${registro.lectura}"

        // Formatear la fecha
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        holder.textViewFecha.text = "Fecha: ${dateFormat.format(registro.instante)}"
    }

    override fun getItemCount(): Int = registros.size
}
