package com.example.appagricola

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ActivityUbicaciones : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ubicaciones)

        // Agregar ubicaciones de muestra si la lista está vacía
        if (DataStorage.ubicaciones.isEmpty()) {
            DataStorage.ubicaciones.add(DataModels.Ubicacion(1, "Invernadero", "Área principal de cultivo"))
            DataStorage.ubicaciones.add(DataModels.Ubicacion(2, "Campo Este", "Campo al este de la granja"))
            DataStorage.ubicaciones.add(DataModels.Ubicacion(3, "Almacén", "Espacio de almacenamiento"))
        }

        val editTextNombre = findViewById<EditText>(R.id.editTextNombreUbicacion)
        val editTextDescripcion = findViewById<EditText>(R.id.editTextDescripcionUbicacion)
        val buttonGuardar = findViewById<Button>(R.id.buttonGuardarUbicacion)

        buttonGuardar.setOnClickListener {
            val nombre = editTextNombre.text.toString()
            val descripcion = editTextDescripcion.text.toString()

            if (nombre.isEmpty() || descripcion.isEmpty()) {
                Toast.makeText(this, "Todos los campos deben ser rellenados", Toast.LENGTH_SHORT).show()
            } else if (nombre.length !in 5..15) {
                Toast.makeText(this, "El nombre debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show()
            } else if (descripcion.length > 30) {
                Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show()
            } else {
                val ubicacion = DataModels.Ubicacion(
                    id = DataStorage.ubicaciones.size + 1,
                    nombre = nombre,
                    descripcion = descripcion
                )
                DataStorage.ubicaciones.add(ubicacion)

                editTextNombre.text.clear()
                editTextDescripcion.text.clear()

                Toast.makeText(this, "Ubicación guardada correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
