// MainActivity.kt
package com.example.appagricola

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import com.example.appagricola.manager.LocationManager
import com.example.appagricola.manager.SensorManager
import com.example.appagricola.manager.HistoryManager

class MainActivity : AppCompatActivity() {
    private lateinit var btnUbicaciones: Button
    private lateinit var btnSensores: Button
    private lateinit var btnHistorial: Button

    // Declarar instancias de los managers
    private lateinit var locationManager: LocationManager
    private lateinit var sensorManager: SensorManager
    private lateinit var historyManager: HistoryManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar botones
        btnUbicaciones = findViewById(R.id.btnUbicaciones)
        btnSensores = findViewById(R.id.btnSensores)
        btnHistorial = findViewById(R.id.btnHistorial)

        // Inicializar instancias de los managers con el contexto
        locationManager = LocationManager(this)
        sensorManager = SensorManager(this)
        historyManager = HistoryManager(this)

        // Configurar listeners utilizando los métodos de los managers
        btnUbicaciones.setOnClickListener { locationManager.openLocationActivity() }
        btnSensores.setOnClickListener { sensorManager.openSensorActivity() }
        btnHistorial.setOnClickListener { historyManager.openHistoryActivity() }
    }
}
